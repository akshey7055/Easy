<?php
$servername = 'localhost';
$username = 'id13858900_root';
$password = 'ABCD1234=def';
$dbname = 'id13858900_books';
#$id=$_POST['t1'];
#if($id!="")
#{
#echo "<script>localSession.setItem('t1', $id)</script>";
#}
$c=0;
$a=0;
if($a==0)
{
    session_start();
    $id=$_SESSION['id'];
    $c=$_SESSION['c'];
    if($c!=2)
    {
        echo "<script>alert('Sign In First')
      window.location.replace('./dashboard/examples/signin.php')</script>";
    }
}
$conn=mysqli_connect($servername,$username,$password,$dbname);
if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
                }    
#    echo "<script>$id=localSession.getItem('t1')</script>";
        $first ="SELECT first_name FROM books WHERE id = '$id'";
        $firstresult = mysqli_query($conn ,$first);
        $firstrow = mysqli_fetch_assoc($firstresult);
        $second ="SELECT last_name FROM books WHERE id = '$id'";
        $secondresult = mysqli_query($conn ,$second);
        $secondrow = mysqli_fetch_assoc($secondresult);
        $email ="SELECT email FROM books WHERE id = '$id'";
        $emailresult = mysqli_query($conn ,$email);
        $emailrow = mysqli_fetch_assoc($emailresult);
        $contact ="SELECT contact_no FROM books WHERE id = '$id'";
        $contactresult = mysqli_query($conn ,$contact);
        $contactrow = mysqli_fetch_assoc($contactresult);
        $birth ="SELECT birth FROM books WHERE id = '$id'";
        $birthresult = mysqli_query($conn ,$birth);
        $birthrow = mysqli_fetch_assoc($birthresult);
  mysqli_close($conn);
?>
<!DOCTYPE HTML>
<!--
   Industrious by TEMPLATED
   templated.co @templatedco
   Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
   -->
<html>
   <head>
      <title>EasyBooks</title>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
      <meta name="description" content="" />
      <meta name="keywords" content="" />
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="rel.css">
      <link rel="stylesheet" href="assets/css/main.css" />
 <style type="text/css">
 html{
  scroll-behavior: smooth;
}

    .pr {
  box-sizing: border-box;
}

.columns {
  float: left;
  width: 42%;
  padding: 8px;
  left:20px;
  position:relative;
}

.price {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}
.columns2 {
  float: right;
  width: 42%;
  padding: 8px;
  right:20px;
  position:relative;

}

.price2 {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}

.price:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}

.price .header {
  background-color: #111;
  color: white;
  font-size: 25px;
}

.price li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}

.price .grey {
  background-color: #eee;
  font-size: 20px;
}
.price2:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}

.price2 .header {
  background-color: #111;
  color: white;
  font-size: 25px;
}

.price2 li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}

.price2 .grey {
  background-color: #eee;
  font-size: 20px;
}

@media only screen and (max-width: 600px) {
  .columns {
    width: 100%;
    left:0px;
  }
}

@media only screen and (max-width: 600px) {
  .columns2 {
    width: 100%;
    right:0px;
  }
}

         .log1{background-color: white;
         color: black;
         border: 2px solid #4CAF50;
         padding: 15px 32px;
         text-align: center; 
         text-decoration: none;
         display: inline-block;
         font-size: 16px;
         margin: 4px 2px;
         cursor: pointer;
         border-radius: 30%;
         }
         .log2{background-color: white;
         color: black;
         border: 2px solid #f44336;
         padding: 15px 32px;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         font-size: 16px;
         margin: 4px 2px;
         cursor: pointer;
         border-radius: 30%;
         }
         .log1:hover{background-color: #4CAF50;
         color: white;
         border: 2px solid black;
         padding: 15px 32px;
         text-align: center; 
         text-decoration: none;
         display: inline-block;
         font-size: 16px;
         margin: 4px 2px;
         cursor: pointer;
         border-radius: 20%;
         }
         .log2:hover{background-color: #f44336;
         color: white;
         border: 2px solid black;
         padding: 15px 32px;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         font-size: 16px;
         margin: 4px 2px;
         cursor: pointer;
         border-radius: 20%;
         }
         .float-class{
         padding: 0;
         margin: 0;
         }
         .float {
         position: fixed;
         width: 60px;
         height: 60px;
         bottom: 40px;
         right: 40px;
         z-index:1;
         background-color: none;
         text-align: center;}
         .my-float {
         margin-top: 22px;
         }
    
         .map-responsive{
         overflow:hidden;
         padding-bottom:56.25%;
         position:relative;
         height:0;
         }
         .map-responsive iframe{
         left:0;
         top:0;
         height:100%;
         width:100%;
         position:absolute;
         }
         .anim {
         width: 100%;
         height: 100%;
         text-align:center;
         display: flex;
         justify-content: center;
         align-items: center;
         }
         .anim-book {
         transform-style: preserve-3d;
         position: relative;
         height: 220px;
         cursor: pointer;
         backface-visibility: visible;
         }
         .anim-front{
         transform-style: preserve-3d;
         position: absolute;
         width: 120px;
         height: 80%;
         top: 0; left: 0;
         transform-origin: left center;
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: black;
         animation-fill-mode: forwards;
         animation-name: front;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         .anim-back {
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         transform-style: preserve-3d;
         position: absolute;
         width: 120px;
         height: 80%;
         animation-fill-mode: forwards;
         top: 0; left: 0;
         transform-origin: left center;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: Black;
         animation-name: back;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         .anim-page1 { 
         transform-style: preserve-3d;
         position: absolute;
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         width: 120px;
         animation-fill-mode: forwards;
         height: 80%;
         top: 0; left: 0;
         transform-origin: left center;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: #efefef;
         animation-name: example1;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         .anim-page2 {
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         transform-style: preserve-3d;
         position: absolute;
         width: 120px;
         height: 80%;
         animation-fill-mode: forwards;
         top: 0; left: 0;
         transform-origin: left center;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: #efefef;
         animation-name: example2;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         .anim-page3 {
         transform-style: preserve-3d;
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         position: absolute;
         width: 120px;
         height: 80%;
         top: 0; left: 0;
         animation-fill-mode: forwards;
         transform-origin: left center;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: #f5f5f5;
         animation-name: example3;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         .anim-page4 {
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         transform-style: preserve-3d;
         position: absolute;
         width: 120px;
         height: 80%;
         top: 0; left: 0;
         transform-origin: left center;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: #f5f5f5;
         animation-fill-mode: forwards;
         animation-name: example4;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         .anim-page5 {
         transform-style: preserve-3d;
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         position: absolute;
         width: 120px;
         height: 80%;
         top: 0; left: 0;
         transform-origin: left center;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: #fafafa;
         animation-name: example5;
         animation-fill-mode: forwards;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         .anim-page6 {
         border-bottom-right-radius: .5em;
         border-top-right-radius: .5em;
         transform-style: preserve-3d;
         position: absolute;
         width: 120px;
         height: 80%;
         top: 0; left: 0;
         transform-origin: left center;
         animation-fill-mode: forwards;
         transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
         background: #fdfdfd;
         animation-name: example6;
         animation-duration: 3s;
         animation-iteration-count: 1;
         }
         @keyframes front {
         from{
         }
         to{
         transform: rotateY(-160deg) scale(1.1);
         box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);  
         }
         }
         @keyframes example1 {
         from{
         }
         to{
         transform: rotateY(-150deg) scale(1.1);
         box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
         }
         }
         @keyframes example2 {
         from{
         }
         to{
         transform: rotateY(-30deg) scale(1.1);
         box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
         }
         }
         @keyframes example3 {
         from{
         }
         to{
         transform: rotateY(-140deg) scale(1.1);
         box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
         }
         }
         @keyframes example4 {
         from{
         }
         to{
         transform: rotateY(-40deg) scale(1.1);
         box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
         }
         }
         @keyframes example5 {
         from{
         }
         to{
         transform: rotateY(-130deg) scale(1.1);
         box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
         }
         }
         @keyframes example6 {
         from{
         }
         to{
         transform: rotateY(-50deg) scale(1.1);
         box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
         }
         }
         @keyframes back {
         from{
         }
         to{
         transform: rotateY(-20deg) scale(1.1);
         }
         }
                  .lg{
             width:40%;  display: block;
  margin-left: auto;
  margin-right: auto;
         }
         @media only screen and (max-width: 600px) {
    .lg {
 width:80%;  display: block;
  margin-left: auto;
  margin-right: auto;    }
}
      </style>
   </head>
   <body class="is-preload">
      <!-- Header -->
      <header id="header">
         <a class="logo" href="index.html">  <!-- <img style="height:5px;width:5px;position:absolute;top:0;left:0;" src="logo.png">
         -->
                 Easybooks</a>
         <nav>
            </nav>
         <nav>
            <a href="#menu">Menu</a>
         </nav>
      </header>
      <!-- Nav -->
      <nav id="menu">
         <ul class="links">
             <!--
            <li><a href="dashboard/examples/dashboard.php">DashBoard</a></li>
            -->
            <li><a href="dashboard/examples/profile.php">Profile</a></li>
			<li><a href="#cont">Contact Us</a></li>
			<li><a href="#about">About Us</a></li>
			<li><a href="#services">Services</a></li>
			<li><a href="#pri">Price</a></li>
			<li><a href="cindex.php">Career</a></li>
         </ul>
      </nav>
      <!-- Banner -->
      <section id="banner">
         <div class="inner">
            <h1><img src="./logo.png" class="lg"></h1>
         </div>
         <video autoplay loop muted playsinline src="easybooks.mp4"></video>
      </section>
      <!-- Highlights 
      <section class="wrapper">
         <div class="inner">
            <div class="anim">
               <div class="anim-book">
                  <div class="anim-back"></div>
                  <div class="anim-page6">
                     <h4>Books At Door, Knowledge At Core</h4>
                  </div>
                  <div class="anim-page5"></div>
                  <div class="anim-page4"></div>
                  <div class="anim-page3"></div>
                  <div class="anim-page2"></div>
                  <div class="anim-page1"></div>
                  <div class="anim-front">
                       <h4 style="text-align:center; color:white;top:50;">Easybooks  </h4>
                  </div>
               </div>
            </div>
<br>
<br>
-->
<br>
<br>
<br>
            
               <header class="special">
               <div id="about">
                 <a href="#about"></a><h2 style="text-align:center"><b>About Us</b></h2></a>
            </header>
            <p>
             We provide a low-cost solution to all your semester exam problems, light on your pocket. We offer a hassle-free delivery and are a one-stop-shop for your academic books. Having faced problems arranging for textbooks ourselves we came up with a solution, with a goal to make textbooks available and affordable for every student. With the requirement of multiple readings, many of us spend money on expensive books without using them much. EasyBooks provides you with a platform to acquire these readings and books with our 24*7 support assistant commitment to serving customers.
</p>
<br>
            <div style="text-align:center">
            <a href="#pri"><button class="button" ><span>Prices</span></button></a>
            <button class="button" id="myBtn"><span>Contact Us </span></button>
            </div>
            </div>
            <!-- The Modal -->
            <div id="myModal" class="modal">
               <!-- Modal content -->
               <div class="modal-content">
                  <div class="modal-header">
                     <span class="close">&times;</span>
                     <h3>Contact Us </h3>
                  </div>
                  <div class="modal-body">
<p><span class="glyphicon glyphicon-phone">Call: </span><a href="https://wa.me/919149367276" style="text-decoration:none; color:black;"> +919149367276 </a></p> <p><span class="glyphicon glyphicon-envelope">Email: </span><a href="mailto:easybooks999@gmail.com" style="text-decoration:none; color:black;"> easybooks999@gmail.com</a></p>                  </div>
                  <div class="modal-footer">
                     <h5>We'll get back to you within 24 hours</h5>
                  </div>
               </div>
            </div>
            <br>
            <hr id="services" style="width: 100%; text-align: right; margin-right: 0;">
            <br>
            <header class="special">
               <h2><b>SERVICES</b></h2>
               <p>What we offers</p>
            </header>
            <div class="highlights">
               <section>
                  <div class="content">
                     <header>
                        <a href="#" class="fa fa-truck" style="font-size:50px;"><span class="label"></span></a>
                        <br>
                        <br>
                        <br>
                        <h3>Door-to-Door Delivery </h3>
                     </header>
                     <hr style="width: 100%; text-align: right; margin-right: 0;">
                     <p>Rent books at efficient cost</p>
                  </div>
               </section>
               <section>
                  <div class="content">
                     <header>
                        <a href="#" class="glyphicon glyphicon-ok " style="font-size:50px;"><span class="label"></span></a>
                        <br>
                        <br>
                        <br>
                        <h3>Availability</h3>
                     </header>
                     <hr style="width: 100%; text-align: right; margin-right: 0;">
                     <p>Easy availability of all kind of academic books</p>
                  </div>
               </section>
               <section>

				<div class="content">
                     <header>
                        <a href="#" class="glyphicon  glyphicon-refresh " style="font-size:50px;"><span class="label"></span></a>
                        <br>
                        <br>
                        <br>
                        <h3>Quick Exchange</h3>
                     </header>
                     <hr style="width: 100%; text-align: right; margin-right: 0;">
                     <p>Promised quick exchange and return
                     <br></p>
				  
				  </div>
               </section>
               <section>
                  <div class="content">
                     <header>
                        <a href="#" class="glyphicon  glyphicon-star " style="font-size:50px;"><span class="label"></span></a>
                        <br>
                        <br>
                        <br>
                        <h3>Special Offers</h3>
                     </header>
                     <hr style="width: 100%; text-align: right; margin-right: 0;">
                     <p>Get discounted coupons of various outlets.</p>
                  </div>
               </section>
               <section>
                  <div class="content">
                     <header>
                        <a href="#" class="glyphicon glyphicon-leaf " style="font-size:50px;"><span class="label"></span></a>
                        <br>
                        <br>
                        <br>
                        <h3>24x7 Assistance</h3>
                     </header>
                     <hr style="width: 100%; text-align: right; margin-right: 0;">
                     <p>Need any help? Call us anytime.</p>
                  </div>
               </section>
               <section>
                  <div class="content">
                     <header>
                        <a href="#" class="glyphicon glyphicon-book" style="font-size:50px;"><span class="label"></span></a>
                        <br>
                        <br>
                        <br>
                        <h3>Books</h3>
                     </header>
                     <hr style="width: 100%; text-align: right; margin-right: 0;">
                     <p>Get unlimited books.</p>
                  </div>
               </section>
            </div>
    	</div>
		</section>
<!--
		<br>
	<br>
	<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br><br>
<br>
<br>
<br>
<br>
-->	<!-- CTA -->
      <section id="cta" class="wrapper">
         <div class="inner">
        <header class="special">
            <h2><b>Message To Parents:</b></h2>
            </header>
                    <p><b>Learning is pivotal for a student’s success in academics and life. The Digital Age is deeply shaping the way students learn and will also determine their future prospects but it’s no match for good old books. BUT, sometimes it could be hard on pocket of students.</b>
<br>

<b>This is where we come in. having faced similar problems while arranging books in our college and determined to come up with a solution, we came up with this start-up.</b>
<br>
<b>WE PROVIDE UNLIMITED BOOKS FOR A FIXED FEE.</b>
<br>
<b>As parents, you understand better why a student need books even if they don’t understand it yet. Gift our subscription to your child and help them get a load off their back.</b>
<br>
<b>Take a look at our subscription prices, ping us and we will get back to you.</b>
            </p> </div>
      </section>
      <br id="pri">
	  <section class="wrapper">
         <div class="inner">
             <header class="special">
	  <h2 class="text-center"> <b>Prices</b> </h1>
</header>
<br>
<div class="columns">
  <ul class="price">
    <li class="header" style="background-color:#FF7969;">Basic</4i>
    <li class="grey">Rs. 2000, Security</li>
    <li>₹ 500/Sem</li>
    <li>Refurbished Books</li>
    <li>Exchange And Delivery</li>
  </ul>
</div>

<div class="columns2">
  <ul class="price2">
    <li class="header" style="background-color:#FF7969;">Pro</li>
    <li class="grey">Rs. 4000, Security</li>
    <li>₹ 1500/Sem</li>
    <li>New Books</li>
    <li>Free Exchange and Delivery</li>
  </ul>
</div>
</div>
</secion>
	  <br>
	  <br>
	  

	  <!-- Testimonials -->
         <!--
         
      <section class="wrapper">
         <div class="inner">
            <header class="special">
               <br>
               <h2>Team</h2>
            </header>
            <div class="testimonials">
               <section>
                  <div class="content">
                     <blockquote>
                        <p>This Is Archit, And I'll Share My Words With You Here.</p>
                     </blockquote>
                     <div class="author">
                        <div class="image">
                           <img src="archit.jpg" alt="" />
                        </div>
                        <p class="credit">- <strong>Archit</strong> <span>CEO - Easybooks.</span></p>
                     </div>
                  </div>
               </section>
               <section>
                  <div class="content">
                     <blockquote>
                        <p>This Is Varshit, And I'll Share My Words With You Here.</p>
                     </blockquote>
                     <div class="author">
                        <div class="image">
                           <img src="varshit.jpg" alt="" />
                        </div>
                        <p class="credit">- <strong>Varshit</strong> <span>CEO - Easybooks.</span></p>
                     </div>
                  </div>
               </section>
               <section>
                  <div class="content">
                     <blockquote>
                        <p>This Is Akshey, And I'll Share My Words With You Here.</p>
                     </blockquote>
                     <div class="author">
                        <div class="image">
                           <img src="akshey2.jpg" alt="" />
                        </div>
                        <p class="credit">- <strong>Akshey Arora</strong> <br><span>Web Development Head - Easybooks.</span></p>
                     </div>
                  </div>
               </section>
            </div>
            
         </div>
	  </section>
	  -->

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
      <div class="float-class">
         <div class="float">
            <a href="https://wa.me/919149367276" target="_blank"><img src="https://img.icons8.com/color/96/000000/whatsapp.png"></a>
         </div>
	  </div>
	<section class="wrapper">
         <div class="inner">
<header class="special">
			<h2 style="text-align: center; font-size: 30px;color: #2A3C4A;font-weight: bolder;letter-spacing: -1px; font-family: 'Montserrat',Futura,Century Gothic,CenturyGothic,AppleGothic,sans-serif, sans-serif; color:#4CAF50"><b>Our Happy Customers</b></h1>
</header>
		<div class="row counters">

			<div class="col-lg-3 col-6 text-center" style="">
				<h4 style="font-size: 15px;"><b>Over</b></h4>
				<span class="counter-up" style=" font-size:50px;"><b><font color="#FF7969">250+</font></b>
				</span>
				<h3 style="font-size: 16px;"><b>Satisfied Customers</b></h3>
			</div>

			<div class="col-lg-3 col-6 text-center" style="">
				<h4 style="font-size: 15px;"><b>Provided More than</b></h4>
				<span class="counter-up" style="font-size:50px;"><b><font color="#FFB96C">3000+</font></b></span>
				<h3 style="font-size: 16px;"><b>Books</b></h3>
			</div>
<script>
			(function ($){
  $.fn.counter = function() {
    const $this = $(this),
    numberFrom = parseInt($this.attr('data-from')),
    numberTo = parseInt($this.attr('data-to')),
    delta = numberTo - numberFrom,
    deltaPositive = delta > 0 ? true : false,
    time = parseInt($this.attr('data-time')),
    changeTime = 10;
    
    let currentNumber = numberFrom,
    value = delta*changeTime/time;
    var interval1;
    const changeNumber = () => {
      currentNumber += value;
      //checks if currentNumber reached numberTo
      (deltaPositive && currentNumber >= numberTo) || (!deltaPositive &&currentNumber<= numberTo) ? currentNumber=numberTo : currentNumber;
      this.text(parseInt(currentNumber));
      currentNumber == numberTo ? clearInterval(interval1) : currentNumber;  
    }

    interval1 = setInterval(changeNumber,changeTime);
  }
}(jQuery));

$(document).ready(function(){

  $('.count-up').counter();
  $('.count1').counter();
  $('.count2').counter();
  $('.count3').counter();
  $('.count4').counter();
  
  new WOW().init();
  
  setTimeout(function () {
    $('.count5').counter();
  }, 3000);
});
</script>
			<br>
			<!--
			<div class="col-lg-3 col-6 text-center">
				<h4 style="font-size: 15px;">RATED</h4>
				<span class="counter-up" style="color: #8DB574">4.7</span>
				<h3 style="font-size: 16px;">Stars Out of 5</h3>
			</div>
			-->
		</div>
	</div>
	</div>
</section>
	  <div class="container container-padd">
        
        <br id="cont">
        <header class="special">
         <h2 class="text-center"><b>CONTACT</b> </h2>
		 </header>
		 <hr style="width: 100%; text-align: right; margin-right: 0;">
              <p><span class="glyphicon glyphicon-map-marker"></span><a href="" style="text-decoration:none;color:black;"> EasyBooks</a></p>
              <p><span class="glyphicon glyphicon-phone"></span><a href="https://wa.me/919149367276" style="text-decoration:none; color:black;"> +919149367276 </a></p>
              <p><span class="glyphicon glyphicon-envelope"></span><a href="mailto:easybooks999@gmail.com" style="text-decoration:none; color:black;"> easybooks999@gmail.com</a></p>
			  <hr style="width: 100%; text-align: right; margin-right: 0;">
			</div>
            <br>
<br>
<br>
<br>
<br>
<br>
      <br>
      </div>
      </div>
      </section>
      <!-- Footer -->
      <footer class="footer footer-hover" style="position: absolute; left: 0; bottom: 0; width: 100%;">
         <a  href="https://www.facebook.com/EasyBooks999/">  <i class="fa fa-facebook-official ss-hover-opacity"  style="font-size:36px">  </i></a>
         <!--
         <i class="fa fa-instagram ss-hover-opacity"  style="font-size:36px;"></i>
         -->
         <a href="mailto:easybooks999@gmail.com" style="text-decoration:none;">
         <i class="glyphicon glyphicon-envelope"  style="font-size:36px"></i></a>
         <a href="https://www.linkedin.com/company/easybooks-in"><i class="fa fa-linkedin ss-hover-opacity"  style="font-size:36px"></i></a>
         <br>
         <p class="text-center" style="font-size:12;">Copywrite@2018 EASYBOOKS</p>
      </footer>
      </body>
      <script>
         $(document).ready(function(){
           // Add smooth scrolling to all links in navbar + footer link
           $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
         	// Make sure this.hash has a value before overriding default behavior
         	if (this.hash !== "") {
         	  // Prevent default anchor click behavior
         	  event.preventDefault();
         
         	  // Store hash
         	  var hash = this.hash;
         
         	  // Using jQuery's animate() method to add smooth page scroll
         	  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
         	  $('html, body').animate({
         		scrollTop: $(hash).offset().top
         	  }, 900, function(){
            
         		// Add hash (#) to URL when done scrolling (default click behavior)
         		window.location.hash = hash;
         	  });
         	} // End if
           });
           
           $(window).scroll(function() {
         	$(".slideanim").each(function(){
         	  var pos = $(this).offset().top;
         
         	  var winTop = $(window).scrollTop();
         		if (pos < winTop + 600) {
         		  $(this).addClass("slide");
         		}
         	});
           });
         })
         
         // Get the modal
         var modal = document.getElementById('myModal');
         
         // Get the button that opens the modal
         var btn = document.getElementById("myBtn");
         
         // Get the <span> element that closes the modal
         var span = document.getElementsByClassName("close")[0];
         
         // When the user clicks the button, open the modal 
         btn.onclick = function() {
         	modal.style.display = "block";
         }
         
         // When the user clicks on <span> (x), close the modal
         span.onclick = function() {
         	modal.style.display = "none";
         }
         
         // When the user clicks anywhere outside of the modal, close it
         window.onclick = function(event) {
         	if (event.target == modal) {
         		modal.style.display = "none";
         	}
         }	
         
      </script>
      <script>
         function display(){
         document.getElementById('id01').style.display='block';
         }
           
      </script>
      <script>
$(document).ready(function(){
  // Add smooth scrolling to all links
  $("a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
});

</script>
      <div class="w3-container">
         <div id="id01" class="w3-modal">
            <div class="w3-modal-content w3-card-4">
               <header class="w3-container w3-teal">
                  <span onclick="document.getElementById('id01').style.display='none'" 
                     class="w3-button w3-display-topright">&times;</span>
                  <h3 style="font-style:Arial ;">Header Or Subject</h3>
               </header>
               <div class="w3-container">
                  <br>
                  <p>
                     EasyBooks is a very humble start-up originated and operating in Thapar university, Patiala. As engineering students, we often faced difficulties arranging books to study, since money is tight when you are in hostel. hence, we came up with EasyBooks. we provide unlimited books for a semester at a very nominal membership fee of Rs. 750. currently, we have around 250 customers in our college and our looking to expand to colleges in Delhi-NCR. we are building a team of students from various colleges in Delhi-NCR who will represent EasyBooks in their respective campus. 
                     Hoping to connect with some dynamic student who like to take initiatives.
                     For more details contact - 9149367276
                  </p>
                  <!--<h3>This Is Made By Most Intelligent Akshey And Devansh,  Don't Thank Us It's Ok</h3>
                     <h3>Chal Ab Bhaag Ja Yaha Se</h3>
                     -->
                  <br>
               </div>
               <footer class="w3-container w3-teal">
                  <h3 style="font-style:Arial ;">Footer</h3>
               </footer>
            </div>
         </div>
      </div>
      <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/browser.min.js"></script>
      <script src="assets/js/breakpoints.min.js"></script>
      <script src="assets/js/util.js"></script>
      <script src="assets/js/main.js"></script>
   </body>
</html>
